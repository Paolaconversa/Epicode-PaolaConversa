Create table Paziente(
Codice int Primary Key,
Cognome varchar (200),
Nome varchar (200),
CodFis varchar (16));

select*
from Paziente

Create Table Reparto(
CodReparto int Primary Key,
Nome varchar (200),
Descrizione varchar (200),
CodiceMedicoPrimario int);

select*
from Reparto

create table Medico(
Codice int Primary Key,
Cognome varchar (200),
Nome varchar (200),
CodFis varchar (16),
CodReparto int,
DataAssegnazione Date,
Foreign key (CodReparto) References Reparto (CodReparto));

select*
from Medico

create table Ricovero(
CodRicovero int Primary Key,
DataInizio Date,
DataFine date,
CodicePaziente int,
CodReparto int,
foreign key (CodicePaziente) references Paziente (Codice),
Foreign key (CodReparto) references Reparto (CodReparto));

select*
from Ricovero

alter table reparto
add foreign key (CodiceMedicoPrimario) references Medico (Codice)

select CodFis as CodiceFiscale
from Paziente
group by CodFis

select DataInizio, count(*) as DataInizioConteggio
from Ricovero
group by DataInizio

select DataAssegnazione
from Medico
Group by DataAssegnazione
Order by DataAssegnazione desc

select*
from Ricovero
where DataInizio>='2020-01-01'

select*
from Ricovero
where DataFine between '2019-03-05' and '2020-09-01'

select*
from Paziente
where Codice IN (1411,1420,1523)

select*
from Paziente
where Nome LIKE '%D%' OR 
Nome LIKE '%OR%'


select*
from Medico
order by CodReparto desc

select Reparto.Nome
from Reparto
left join Ricovero as Ricoverati
ON Reparto.CodiceMedicoPrimario=Ricoverati.CodicePaziente

